﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BudLib.library;

namespace Test
{
    public partial class Register : System.Web.UI.Page
    {
        myDatabaseEntities db = new myDatabaseEntities();
        Functionality fn = new Functionality();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BtnRegister_Click(object sender, EventArgs e)
        {
            try {
                if (txtUser.Text != null && txtUser.Text != "" && txtPass.Text != "" && txtPass.Text != null)
                {
                    Person user = new Person();
                    string hashPass = txtPass.Text;
                    user.UserName = txtUser.Text.Trim();
                    user.Password = fn.hash(txtPass.Text.Trim()).Trim();

                    db.People.Add(user);
                    db.SaveChanges();
                    lblMsg.Text = "user registered";
                }
                else
                {
                    lblMsg.Text = "error! enter all fields";
                }
            }catch(Exception me)
            {

            }

        }
    }
}