﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Test
{
    public class myClass
    {
        // creating entities object
        






        //method to store data in the database
        public void dataStore(int loginID, string Income, string Tax, string waterLights, string cellPhone, string Others, string totalExpense,
            string rentalAmounts, string priceProperty, string houseDeposit, string interestRate, string monthlyPay, string houseCost, string houseMonthly,
            string modelName, string carPurchase, string carDeposit, string carRate, string Insurance, string vehicleCost,string Msg)
        {

            try
            {
                myDatabaseEntities UpdateEntity = new myDatabaseEntities();
                Person data = UpdateEntity.People.FirstOrDefault(i => i.ID == loginID);
                data.Income = Income;
                data.Tax = Tax;
                data.waterLights = waterLights;
                data.cellPhone = cellPhone;
                data.Others = Others;
                data.totalExpense = totalExpense;
                data.rentalAmounts = rentalAmounts;
                data.priceProperty = priceProperty;
                data.houseDeposit = houseDeposit;
                data.interestRate = interestRate;
                data.monthlyPay = monthlyPay;
                data.modelName = modelName;
                data.carPurchase = carPurchase;
                data.carDeposit = carDeposit;
                data.carRate = carRate;
                data.Insurance = Insurance;
                data.vehicleCost = vehicleCost;

                UpdateEntity.SaveChanges();

                Msg = "Changes saved";
              

              
            }
            catch (Exception e)
            {
                Msg ="Error "+ e.Message;
            }


        }


    }
}