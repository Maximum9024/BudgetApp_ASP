﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BudLib.library;
namespace Test
{
    public partial class homePage : System.Web.UI.Page
    {
        Functionality fn = new Functionality();
        myDatabaseEntities db = new myDatabaseEntities();
        
        double allExpenses = 0;
        string userID = "";

        
        protected void Page_Load(object sender, EventArgs e)
        {
            List<Person> objUser = db.People.ToList<Person>();
            userID = Request.QueryString["uID"];
            lblUserName.Text = userID;
            //foreach (Person u in objUser)
            //{
            //    if (userID.Equals(u.ID))
            //    {
            //        lblUserName.Text = u.UserName;
            //    }
            //    else
            //    {
            //        lblUserName.Text = "no user";
            //    }
            //}
           
        }

        protected void btnExp_Click(object sender, EventArgs e)
        {
          allExpenses=  Expenses.Month(Double.Parse(txtGrocery.Text), Double.Parse(txtWlights.Text), Double.Parse(txtTraCost.Text), Double.Parse(txtcellphone.Text), Double.Parse(txtOthers.Text));

            txtTotal.Text = allExpenses.ToString();
        }

        protected void btnHCalc_Click(object sender, EventArgs e)
        {
            if (rdoBuy.Checked==true)
            {
                fn.getAcc_Cost(txtPropPrice.Text, txtHDeposit.Text, txtHRate.Text, txtmRepay.Text);
                txtHCost.Text = fn.getTotal_Monthly_Cost().ToString();
                txtAccomCost.Text = fn.getTotal_Home_Cost().ToString();


            }
            if (rdoRent.Checked == true)
            {
                txtHCost.Text = fn.get_Rent(txtRent.Text).ToString();
                txtAccomCost.Text= fn.get_Rent(txtRent.Text).ToString();

            }

        }

        protected void BtnVCalc_Click(object sender, EventArgs e)
        {
            //calculating the vehicle cost
            fn.get_VehicleCost(txtCprice.Text, txtCDeposit.Text, txtCRate.Text, txtInsure.Text);
            txtCTotal.Text = fn.getVehicle_Cost().ToString();

        }

        protected void btnResults_Click(object sender, EventArgs e)
        {
            fn.Display_Results(lblResults.Text, txtGrocery.Text, txtTax.Text, txtTotal.Text, txtHCost.Text, txtAccomCost.Text, txtCTotal.Text,lblApprove.Text);
        }

        protected void txtDisp_TextChanged(object sender, EventArgs e)
        {

        }
    }
}