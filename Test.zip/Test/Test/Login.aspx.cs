﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BudLib.library;

namespace Test
{
    public partial class Login : System.Web.UI.Page
    {
        myDatabaseEntities db = new myDatabaseEntities();
       
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
            try {
                if (txtUserBox.Text != null && txtUserBox.Text != "" && txtPassBox.Text != null && txtPassBox.Text != "") {

                    List<Person> objUser = db.People.ToList<Person>();
                    Functionality fn = new Functionality();

                    foreach(Person u in objUser)
                    {
                        string user = txtUserBox.Text; ;
                        string pass = fn.hash(txtPassBox.Text);
                        if(u.UserName.Equals(user)&& u.Password.Equals(pass))
                        {
                            Response.Redirect("homePage.aspx?ID="+u.UserName);
                            
                        }
                        else
                        {
                            lblError.Text = "User does not exist";
                        }
                    }
                }
                else
                {
                    lblError.Text = "please enter user  and password";
                }
            }
            catch (Exception me)
            {
                lblError.Text = me.Message;
            }

            
        }
    }
}